def exist():
    print('l')